@echo off
title CITRIX KEYBOARD INPUT TESTER
color 0e
cd /d "%~dp0"
python test_vm_input.py
pause
