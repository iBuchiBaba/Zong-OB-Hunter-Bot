from datetime import datetime, date, time as dtime

def evaluate_refined_rules(rows, today_str=None):
    if today_str is None:
        today_str = datetime.now().strftime('%Y-%m-%d')
    today_dt = datetime.strptime(today_str, '%Y-%m-%d').date()
    
    if not rows:
        return 'A', 'Fresh lead (0 records)'
        
    recent_connected_days = None
    expiring_connected_days = None
    has_zero_today = False
    has_past_zero = False
    
    for r in rows:
        phone = str(r.get('phone', '')).strip()
        
        # 1. Flash call check: if without zero (315...), it's a Flash call -> IGNORE from connected check!
        if phone and not phone.startswith('0'):
            # Flash call does not block hunting
            continue
            
        # 2. Time filter: 9 AM to 9 PM
        call_time = r.get('time', dtime(12, 0))
        if not (dtime(9, 0) <= call_time <= dtime(21, 0)):
            # Outside 9am - 9pm, ignore
            continue
            
        call_date = r.get('date', today_dt)
        days_ago = (today_dt - call_date).days
        dur = int(r.get('duration', 0))
        
        # Rule 1: Connected call means duration >= 7 seconds!
        if dur >= 7:
            if 0 <= days_ago <= 14:
                if recent_connected_days is None or days_ago < recent_connected_days:
                    recent_connected_days = days_ago
            elif 15 <= days_ago <= 20:
                if expiring_connected_days is None or days_ago < expiring_connected_days:
                    expiring_connected_days = days_ago
        else:
            # Duration < 7 -> Zero duration / missed call
            if days_ago == 0:
                has_zero_today = True
            elif days_ago > 0:
                has_past_zero = True
                
    # Decision Hierarchy:
    # 1. Recent Connected Call (0-14 days)
    if recent_connected_days is not None:
        return 'd', f'Connected call {recent_connected_days} days ago (0-14 days)'
        
    # 2. Expiring Connected Call (15-20 days)
    if expiring_connected_days is not None:
        return 'w', f'Connected call {expiring_connected_days} days ago (15-20 days)'
        
    # 3. Zero duration call TODAY (Hunting day)
    if has_zero_today:
        return '', 'Zero duration call attempted today (blank)'
        
    # 4. Zero duration call in past (yesterday/older) & NO call today -> OPEN NUMBER!
    if has_past_zero:
        return 'A', 'Open Number (Zero call was in past, missed today!)'
        
    # 5. Fresh lead or Flash calls only
    return 'A', 'Eligible lead (Fresh or Flash calls only)'

if __name__ == '__main__':
    today = '2026-10-09'
    
    # 1. Fresh lead
    s, r = evaluate_refined_rules([], today)
    print("Test 1 (Fresh 0 records):", s, "->", r)
    assert s == 'A'
    
    # 2. Yesterday zero duration call (dur=0, days_ago=1)
    s, r = evaluate_refined_rules([{'date': date(2026, 10, 8), 'duration': 0, 'phone': '03151234567'}], today)
    print("Test 2 (Yesterday zero):", s, "->", r)
    assert s == 'A'
    
    # 3. 3 days ago zero duration call
    s, r = evaluate_refined_rules([{'date': date(2026, 10, 6), 'duration': 0, 'phone': '03151234567'}], today)
    print("Test 3 (3 days ago zero):", s, "->", r)
    assert s == 'A'
    
    # 4. Today zero duration call
    s, r = evaluate_refined_rules([{'date': date(2026, 10, 9), 'duration': 0, 'phone': '03151234567'}], today)
    print("Test 4 (Today zero):", repr(s), "->", r)
    assert s == ''
    
    # 5. Connected call today (dur=15 >= 7)
    s, r = evaluate_refined_rules([{'date': date(2026, 10, 9), 'duration': 15, 'phone': '03151234567'}], today)
    print("Test 5 (Today connect 15s):", s, "->", r)
    assert s == 'd'
    
    # 6. Connected call 17 days ago
    s, r = evaluate_refined_rules([{'date': date(2026, 9, 22), 'duration': 25, 'phone': '03151234567'}], today)
    print("Test 6 (Connect 17 days ago):", s, "->", r)
    assert s == 'w'
    
    # 7. Flash call (without 0: 315...) with duration 60s
    s, r = evaluate_refined_rules([{'date': date(2026, 10, 9), 'duration': 60, 'phone': '3151234567'}], today)
    print("Test 7 (Flash call without 0):", s, "->", r)
    assert s == 'A'
    
    # 8. Flash call + Yesterday zero call
    s, r = evaluate_refined_rules([
        {'date': date(2026, 10, 9), 'duration': 60, 'phone': '3151234567'},
        {'date': date(2026, 10, 8), 'duration': 0, 'phone': '03151234567'}
    ], today)
    print("Test 8 (Flash call + Yesterday zero):", s, "->", r)
    assert s == 'A'
    
    # 9. Call with duration 5s (< 7s) yesterday
    s, r = evaluate_refined_rules([{'date': date(2026, 10, 8), 'duration': 5, 'phone': '03151234567'}], today)
    print("Test 9 (Duration 5s < 7s):", s, "->", r)
    assert s == 'A'
    
    print("\nALL 9 REFINED RULE UNIT TESTS PASSED!")
