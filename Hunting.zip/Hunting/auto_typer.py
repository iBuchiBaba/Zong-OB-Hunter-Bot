import ctypes
import os
import sys
import time
import winsound

PUL = ctypes.POINTER(ctypes.c_ulong)

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ('wVk', ctypes.c_ushort),
        ('wScan', ctypes.c_ushort),
        ('dwFlags', ctypes.c_ulong),
        ('time', ctypes.c_ulong),
        ('dwExtraInfo', PUL)
    ]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ('uMsg', ctypes.c_ulong),
        ('wParamL', ctypes.c_short),
        ('wParamH', ctypes.c_ushort)
    ]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ('dx', ctypes.c_long),
        ('dy', ctypes.c_long),
        ('mouseData', ctypes.c_ulong),
        ('dwFlags', ctypes.c_ulong),
        ('time', ctypes.c_ulong),
        ('dwExtraInfo', PUL)
    ]

class Input_I(ctypes.Union):
    _fields_ = [
        ('ki', KEYBDINPUT),
        ('mi', MOUSEINPUT),
        ('hi', HARDWAREINPUT)
    ]

class INPUT(ctypes.Structure):
    _fields_ = [
        ('type', ctypes.c_ulong),
        ('ii', Input_I)
    ]

user32 = ctypes.windll.user32

KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
INPUT_KEYBOARD = 1

def send_char(char):
    if char == '\r':
        return
    if char == '\n':
        # Send VK_RETURN
        ki_down = KEYBDINPUT(0x0D, 0, 0, 0, None)
        ki_up = KEYBDINPUT(0x0D, 0, KEYEVENTF_KEYUP, 0, None)
        events = (INPUT * 2)(INPUT(INPUT_KEYBOARD, Input_I(ki=ki_down)),
                             INPUT(INPUT_KEYBOARD, Input_I(ki=ki_up)))
        user32.SendInput(2, events, ctypes.sizeof(INPUT))
        time.sleep(0.02)
        return

    if char == '\t':
        ki_down = KEYBDINPUT(0x09, 0, 0, 0, None)
        ki_up = KEYBDINPUT(0x09, 0, KEYEVENTF_KEYUP, 0, None)
        events = (INPUT * 2)(INPUT(INPUT_KEYBOARD, Input_I(ki=ki_down)),
                             INPUT(INPUT_KEYBOARD, Input_I(ki=ki_up)))
        user32.SendInput(2, events, ctypes.sizeof(INPUT))
        time.sleep(0.005)
        return

    code = ord(char)
    ki_down = KEYBDINPUT(0, code, KEYEVENTF_UNICODE, 0, None)
    ki_up = KEYBDINPUT(0, code, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP, 0, None)
    events = (INPUT * 2)(INPUT(INPUT_KEYBOARD, Input_I(ki=ki_down)),
                         INPUT(INPUT_KEYBOARD, Input_I(ki=ki_up)))
    user32.SendInput(2, events, ctypes.sizeof(INPUT))
    time.sleep(0.003)

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(script_dir, "code.txt")
    if not os.path.exists(file_path):
        print(f"Error: {file_path} not found!")
        input("Press Enter to exit...")
        return

    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    total_chars = len(text)
    print("=" * 60)
    print("   AUTO-TYPER FOR VM (NOTEPAD)")
    print("=" * 60)
    print(f"Loaded {total_chars} characters from code.txt.")
    print()
    print("Countdown start ho raha hai:")
    print(">>> 7 SECONDS MEIN VM WINDOW PAR JAYEIN AUR NOTEPAD PAR CLICK KAREIN! <<<")
    print()

    for i in range(7, 0, -1):
        print(f"Starting in {i} second{'s' if i > 1 else ''}...")
        try:
            winsound.Beep(900, 150)
        except Exception:
            pass
        time.sleep(0.85)

    print()
    print(">>> TYPING STARTED! (Window ko disturb mat karein) <<<")
    try:
        winsound.Beep(1400, 300)
    except Exception:
        pass

    start_time = time.time()
    for idx, c in enumerate(text):
        send_char(c)
        if (idx + 1) % 100 == 0 or idx + 1 == total_chars:
            pct = int(((idx + 1) / total_chars) * 100)
            sys.stdout.write(f"\rProgress: {pct}% ({idx + 1}/{total_chars} chars)")
            sys.stdout.flush()

    elapsed = time.time() - start_time
    print(f"\n\nTyping mukammal ho gayi in {elapsed:.1f} seconds!")
    try:
        winsound.Beep(1500, 200)
        time.sleep(0.1)
        winsound.Beep(1800, 350)
    except Exception:
        pass

    print("=" * 60)
    print("All done! Notepad check karein.")
    input("Press Enter to close this window...")

if __name__ == "__main__":
    main()
