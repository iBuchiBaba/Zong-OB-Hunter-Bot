import json
import os
import re
import sys
import time
import winsound
from datetime import datetime, time as dtime
import numpy as np
import pyautogui
import pyperclip
from PIL import ImageGrab
from rapidocr_onnxruntime import RapidOCR

import ctypes

PUL = ctypes.POINTER(ctypes.c_ulong)

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ('wVk', ctypes.c_ushort),
        ('wScan', ctypes.c_ushort),
        ('dwFlags', ctypes.c_ulong),
        ('time', ctypes.c_ulong),
        ('dwExtraInfo', PUL)
    ]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ('uMsg', ctypes.c_ulong),
        ('wParamL', ctypes.c_short),
        ('wParamH', ctypes.c_ushort)
    ]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ('dx', ctypes.c_long),
        ('dy', ctypes.c_long),
        ('mouseData', ctypes.c_ulong),
        ('dwFlags', ctypes.c_ulong),
        ('time', ctypes.c_ulong),
        ('dwExtraInfo', PUL)
    ]

class Input_I(ctypes.Union):
    _fields_ = [
        ('ki', KEYBDINPUT),
        ('mi', MOUSEINPUT),
        ('hi', HARDWAREINPUT)
    ]

class INPUT(ctypes.Structure):
    _fields_ = [
        ('type', ctypes.c_ulong),
        ('ii', Input_I)
    ]

user32 = ctypes.windll.user32

KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
INPUT_KEYBOARD = 1

VK_SHIFT = 0x10
VK_CONTROL = 0x11
VK_HOME = 0x24
VK_END = 0x23
VK_UP = 0x26
VK_DOWN = 0x28
VK_A = 0x41
VK_C = 0x43
VK_V = 0x56

def press_extended_key(vk):
    ki_down = KEYBDINPUT(vk, 0, KEYEVENTF_EXTENDEDKEY, 0, None)
    ki_up = KEYBDINPUT(vk, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0, None)
    events = (INPUT * 2)(INPUT(INPUT_KEYBOARD, Input_I(ki=ki_down)),
                         INPUT(INPUT_KEYBOARD, Input_I(ki=ki_up)))
    user32.SendInput(2, events, ctypes.sizeof(INPUT))
    time.sleep(0.04)

def hotkey_ctrl(key_vk):
    k1 = KEYBDINPUT(VK_CONTROL, 0, 0, 0, None)
    k2 = KEYBDINPUT(key_vk, 0, 0, 0, None)
    k3 = KEYBDINPUT(key_vk, 0, KEYEVENTF_KEYUP, 0, None)
    k4 = KEYBDINPUT(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0, None)
    events = (INPUT * 4)(
        INPUT(INPUT_KEYBOARD, Input_I(ki=k1)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k2)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k3)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k4))
    )
    user32.SendInput(4, events, ctypes.sizeof(INPUT))
    time.sleep(0.05)

def ctrl_home():
    k1 = KEYBDINPUT(VK_CONTROL, 0, 0, 0, None)
    k2 = KEYBDINPUT(VK_HOME, 0, KEYEVENTF_EXTENDEDKEY, 0, None)
    k3 = KEYBDINPUT(VK_HOME, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0, None)
    k4 = KEYBDINPUT(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0, None)
    events = (INPUT * 4)(
        INPUT(INPUT_KEYBOARD, Input_I(ki=k1)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k2)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k3)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k4))
    )
    user32.SendInput(4, events, ctypes.sizeof(INPUT))
    time.sleep(0.06)

def select_and_copy_line():
    # Go to start of line
    press_extended_key(VK_HOME)
    time.sleep(0.04)
    # Shift + End
    k_shift_down = KEYBDINPUT(VK_SHIFT, 0, 0, 0, None)
    k_end_down = KEYBDINPUT(VK_END, 0, KEYEVENTF_EXTENDEDKEY, 0, None)
    k_end_up = KEYBDINPUT(VK_END, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0, None)
    k_shift_up = KEYBDINPUT(VK_SHIFT, 0, KEYEVENTF_KEYUP, 0, None)
    ev_sel = (INPUT * 4)(
        INPUT(INPUT_KEYBOARD, Input_I(ki=k_shift_down)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k_end_down)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k_end_up)),
        INPUT(INPUT_KEYBOARD, Input_I(ki=k_shift_up))
    )
    user32.SendInput(4, ev_sel, ctypes.sizeof(INPUT))
    time.sleep(0.06)
    # Ctrl + C
    hotkey_ctrl(VK_C)
    time.sleep(0.08)

# Safety Settings
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.08

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(SCRIPT_DIR, "coords.json")
LOG_CSV = os.path.join(SCRIPT_DIR, "leads_log.csv")
LEADS_TXT = os.path.join(SCRIPT_DIR, "leads.txt")
CLEAN_LEADS_TXT = os.path.join(SCRIPT_DIR, "clean_huntable_leads.txt")
TEMP_DIR = os.path.join(SCRIPT_DIR, "temp")
os.makedirs(TEMP_DIR, exist_ok=True)

def get_temp_path(filename):
    """Returns absolute path inside the isolated temp directory."""
    os.makedirs(TEMP_DIR, exist_ok=True)
    return os.path.join(TEMP_DIR, filename)

ocr_engine = None

def get_ocr_engine():
    global ocr_engine
    if ocr_engine is None:
        print("RapidOCR engine load ho raha hai...")
        ocr_engine = RapidOCR()
    return ocr_engine

def beep(freq=1200, dur=150):
    try:
        winsound.Beep(freq, dur)
    except Exception:
        pass

def countdown(seconds, message):
    print(f"\n{message}")
    for i in range(seconds, 0, -1):
        print(f"Starting in {i} second{'s' if i > 1 else ''}...")
        beep(900, 100)
        time.sleep(0.9)
    beep(1500, 250)
    print("Action shuru!\n")

def calibrate_coords():
    print("=" * 60)
    print("      ONE-TIME COORDINATE CALIBRATION SETUP")
    print("=" * 60)
    print("Har step par mouse ko bataye gaye point par rakhein.")
    print("Timer khatam hone par mouse ki position khud save ho jayegi!\n")
    
    coords = {}
    
    steps = [
        ("notepad_title", "Step 1: Mouse ko NOTEPAD ki sab se upar TITLE BAR (Top Bar) par rakhein", 5),
        ("calling_input", "Step 2: Mouse ko CRM ke 'Calling number' box par rakhein", 5),
        ("query_button", "Step 3: Mouse ko CRM ke 'Query' button par rakhein", 5),
        ("table_top_left", "Step 4: Mouse ko CRM Table ke TOP-LEFT corner par rakhein", 6),
        ("table_bottom_right", "Step 5: Mouse ko CRM Table ke BOTTOM-RIGHT corner par rakhein", 6),
    ]
    
    for key, prompt, wait_sec in steps:
        countdown(wait_sec, f">>> {prompt} <<<")
        pos = pyautogui.position()
        coords[key] = [pos.x, pos.y]
        print(f"Captured {key}: ({pos.x}, {pos.y})\n")
        beep(1800, 150)
        time.sleep(0.5)
        
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(coords, f, indent=4)
        
    print("=" * 60)
    print(f"Coordinates kamyabi se save ho gaye: {CONFIG_FILE}")
    print("=" * 60)
    return coords

def load_coords():
    if not os.path.exists(CONFIG_FILE):
        return None
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def parse_time_from_str(s):
    """
    Extracts time as datetime.time object from OCR string.
    Handles 'HH:MM:SS', 'HH1MM1SS', 'HH:MM1SS' where ':' might be OCR-read as '1'.
    """
    parts = s.strip().split()
    time_part = parts[-1] if len(parts) > 1 else s
    c = re.sub(r'(?<=\d{2})1(?=\d{2})', ':', time_part)
    digits = re.findall(r'\d+', c)
    if len(digits) == 3:
        h, m, sec = int(digits[0]), int(digits[1]), int(digits[2])
        return dtime(min(h, 23), min(m, 59), min(sec, 59))
    elif len(digits) == 2 and len(digits[1]) == 4:
        h = int(digits[0])
        m = int(digits[1][:2])
        sec = int(digits[1][2:])
        return dtime(min(h, 23), min(m, 59), min(sec, 59))
    elif len(digits) == 1 and len(digits[0]) == 6:
        h = int(digits[0][:2])
        m = int(digits[0][2:4])
        sec = int(digits[0][4:6])
        return dtime(min(h, 23), min(m, 59), min(sec, 59))
    return None

def parse_and_evaluate(crop_img, today_str=None):
    if today_str is None:
        today_str = datetime.now().strftime("%Y-%m-%d")
    today_dt = datetime.strptime(today_str, "%Y-%m-%d").date()
    
    engine = get_ocr_engine()
    if isinstance(crop_img, (str, bytes)):
        results, _ = engine(crop_img)
    elif hasattr(crop_img, '__array__') or hasattr(crop_img, 'shape'):
        results, _ = engine(np.array(crop_img))
    else:
        results, _ = engine(np.array(crop_img))
    
    if not results:
        # Table is empty, no records found
        return "A", "Fresh lead (0 records found in table)", 0, ""
        
    lines = [r[1].strip() for r in results if r[1].strip()]
    full_text = " ".join(lines)
    
    # 1. Total records count check
    total_rec_match = re.search(r'(?:total|tobal)\s*records?\s*[:=]?\s*(\d+)', full_text, re.IGNORECASE)
    total_records = int(total_rec_match.group(1)) if total_rec_match else None
    
    if total_records == 0:
        return "A", "Fresh lead (Total records: 0)", 0, ""

    # Group OCR bounding boxes by row (Y-coordinates)
    items = []
    for r in results:
        box, text = r[0], r[1]
        cx = (box[0][0] + box[1][0]) / 2
        cy = (box[0][1] + box[2][1]) / 2
        items.append({'x': cx, 'y': cy, 'text': text})

    items.sort(key=lambda i: i['y'])

    rows = []
    for it in items:
        t_low = it['text'].lower()
        if 'total' in t_low or 'tobal' in t_low or 'record' in t_low:
            continue
        if it['text'] in ['100', 'Go', 'G0', '1', 'records']:
            continue
            
        placed = False
        for r in rows:
            if abs(r['y'] - it['y']) <= 14:
                r['items'].append(it)
                placed = True
                break
        if not placed:
            rows.append({'y': it['y'], 'items': [it]})

    parsed_records = []
    detected_phone = ""

    for r in rows:
        r['items'].sort(key=lambda i: i['x'])
        row_text = " ".join([i['text'] for i in r['items']])
        
        # 1. Row MUST contain a datetime item (year 2024-2027)
        dt_items = [it for it in r['items'] if re.search(r'202[4-7]', it['text'])]
        if not dt_items:
            # Skip non-call rows (headers, footers, pagination)
            continue
            
        # Parse Call Date
        date_matches = re.findall(r'(\d{4}[-/.]\s*\d{2}[-/.]\s*\d{2})', dt_items[0]['text'])
        if date_matches:
            try:
                d_clean = re.sub(r'\s+', '', date_matches[0]).replace('/', '-').replace('.', '-')
                call_date = datetime.strptime(d_clean, "%Y-%m-%d").date()
            except Exception:
                call_date = today_dt
        else:
            call_date = today_dt

        # 2. Phone numbers in this row
        phones = re.findall(r'\b(0?3\d{9})\b', row_text)
        phone = phones[0] if phones else ""
        if phone and not detected_phone:
            detected_phone = phone

        # 3. Start Datetime is dt_items[0], End Datetime is dt_items[1] (if present)
        start_it = dt_items[0]
        end_it = dt_items[1] if len(dt_items) > 1 else None

        t_start = parse_time_from_str(start_it['text'])
        t_end = parse_time_from_str(end_it['text']) if end_it else None
        
        call_time = t_start if t_start else dtime(12, 0)
        time_dur = 0
        if t_start and t_end:
            sec1 = t_start.hour * 3600 + t_start.minute * 60 + t_start.second
            sec2 = t_end.hour * 3600 + t_end.minute * 60 + t_end.second
            time_dur = abs(sec2 - sec1)

        # 4. Check Contact Duration column strictly between start_it and end_it
        col_dur = 0
        if end_it:
            x_min = start_it['x']
            x_max = end_it['x']
            for it in r['items']:
                if x_min < it['x'] < x_max:
                    # Look for digits inside this specific column item (e.g. '0', '0HNC', '35')
                    m = re.findall(r'\b(\d{1,4})\b', it['text'])
                    for num_s in m:
                        col_dur = max(col_dur, int(num_s))

        final_dur = max(time_dur, col_dur)

        parsed_records.append({
            'phone': phone,
            'date': call_date,
            'time': call_time,
            'duration': final_dur
        })

    if not parsed_records:
        return "A", "Fresh lead (0 records in table)", 0, detected_phone

    recent_connected_days = None
    expiring_connected_days = None
    has_zero_today = False
    has_past_zero = False
    
    for rec in parsed_records:
        p = rec['phone']
        # Rule: Flash call (without leading 0) -> does NOT block hunting!
        if p and not p.startswith('0'):
            continue
            
        # Rule: Time filter (9 AM to 9 PM)
        t = rec['time']
        if not (dtime(9, 0) <= t <= dtime(21, 0)):
            continue
            
        days_ago = (today_dt - rec['date']).days
        dur = rec['duration']
        
        # Rule: Connected call means duration >= 7 seconds!
        if dur >= 7:
            if 0 <= days_ago <= 14:
                if recent_connected_days is None or days_ago < recent_connected_days:
                    recent_connected_days = days_ago
            elif 15 <= days_ago <= 20:
                if expiring_connected_days is None or days_ago < expiring_connected_days:
                    expiring_connected_days = days_ago
        else:
            # Duration < 7 -> Zero duration / missed call
            if days_ago == 0:
                has_zero_today = True
            elif days_ago > 0:
                has_past_zero = True

    count = len(parsed_records)
    # Decision Hierarchy:
    # 1. Recent Connected Call (0-14 days) -> 'd'
    if recent_connected_days is not None:
        return "d", f"Connected call {recent_connected_days} days ago (0-14 days)", count, detected_phone
        
    # 2. Expiring Connected Call (15-20 days) -> 'w'
    if expiring_connected_days is not None:
        return "w", f"Connected call {expiring_connected_days} days ago (15-20 days)", count, detected_phone
        
    # 3. Zero duration call TODAY -> leave blank (attempted today)
    if has_zero_today:
        return "", "Zero duration call attempted today (leave blank)", count, detected_phone
        
    # 4. Zero duration call in past (yesterday/older) & NO call today -> OPEN NUMBER (A)!
    if has_past_zero:
        return "A", "Open Number (Zero call was in past, missed today!)", count, detected_phone
        
    # 5. Fresh lead or Flash calls only -> 'A'
    return "A", "Eligible lead (Fresh or Flash calls only)", count, detected_phone

def log_result(phone, status, reason, records_count):
    try:
        header = not os.path.exists(LOG_CSV)
        with open(LOG_CSV, "a", encoding="utf-8") as f:
            if header:
                f.write("timestamp,phone,status,records_count,reason\n")
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            f.write(f'"{ts}","{phone}","{status}",{records_count},"{reason}"\n')
    except PermissionError:
        backup_csv = os.path.join(SCRIPT_DIR, "leads_log_backup.csv")
        try:
            with open(backup_csv, "a", encoding="utf-8") as f:
                ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                f.write(f'"{ts}","{phone}","{status}",{records_count},"{reason}"\n')
            print("[INFO] leads_log.csv Excel me open hai, is liye entry leads_log_backup.csv me save ho gayi.")
        except Exception:
            pass
    except Exception as e:
        print(f"[LOG ERROR]: {e}")
        
    if status == "A":
        clean_num = re.sub(r'\D', '', phone)
        if len(clean_num) >= 7:
            try:
                with open(CLEAN_LEADS_TXT, "a", encoding="utf-8") as f:
                    f.write(f"{clean_num}\n")
            except Exception:
                pass

def run_vm_notepad_hunter(max_leads=50, query_wait=1.8):
    coords = load_coords()
    if not coords:
        print("Coordinates nahi mile! Pehle Calibration chalayein.")
        coords = calibrate_coords()
        
    n_x, n_y = coords.get("notepad_title") or coords.get("notepad_pos")
    c_x, c_y = coords["calling_input"]
    q_x, q_y = coords["query_button"]
    t_x1, t_y1 = coords["table_top_left"]
    t_x2, t_y2 = coords["table_bottom_right"]
    
    bbox = (min(t_x1, t_x2), min(t_y1, t_y2), max(t_x1, t_x2), max(t_y1, t_y2))
    
    get_ocr_engine()
    
    print("\n" + "=" * 60)
    print("      VM NOTEPAD MODE (IN-VM COPY/PASTE)")
    print("=" * 60)
    print(f"Max Leads to Process: {max_leads}")
    print(f"Query Wait Time: {query_wait}s")
    print("Emergency Stop: Mouse ko Screen ke top-left (0,0) par le jayein!")
    print("=" * 60)
    
    countdown(5, ">>> VM WINDOW SAMNE RAKHEIN <<<")
    
    today_str = datetime.now().strftime("%Y-%m-%d")
    processed = 0
    
    # Initial focus: Click Notepad Title Bar once and move cursor to start of line 1
    pyautogui.click(n_x, n_y)
    time.sleep(0.3)
    ctrl_home()
    time.sleep(0.2)
    
    for idx in range(1, max_leads + 1):
        print(f"\n--- [Lead #{idx}/{max_leads}] ---")
        try:
            # 1. Select and Copy number on current line using hardware extended keys
            select_and_copy_line()
            time.sleep(0.08)
            
            # 2. Click CRM Calling number input
            pyautogui.click(c_x, c_y)
            time.sleep(0.08)
            hotkey_ctrl(VK_A)
            time.sleep(0.04)
            pyautogui.press('backspace')
            time.sleep(0.04)
            
            # 3. Paste directly inside VM using hardware Ctrl+V
            hotkey_ctrl(VK_V)
            time.sleep(0.1)
            
            # 4. Click Query Button
            pyautogui.click(q_x, q_y)
            time.sleep(query_wait)
            
            # 5. Capture screenshot of table
            crop = ImageGrab.grab(bbox=bbox)
            
            # 6. Run OCR and rule evaluation
            status, reason, count, detected_phone = parse_and_evaluate(crop, today_str)
            
            phone_label = detected_phone if detected_phone else f"Lead_{idx}"
            display_status = status if status else "(blank)"
            print(f"Number: {phone_label} | Decision: [{display_status}] -> {reason}")
            
            # Log to host CSV
            log_result(phone_label, status, reason, count)
            
            # 7. Click Notepad Title Bar to focus (cursor stays on current line)
            pyautogui.click(n_x, n_y)
            time.sleep(0.08)
            press_extended_key(VK_END)
            time.sleep(0.05)
            
            if status:
                pyautogui.write(f" - {status}", interval=0.01)
                time.sleep(0.05)
                
            # Move cursor to NEXT LINE using Real Extended Down Key!
            press_extended_key(VK_DOWN)
            time.sleep(0.05)
            press_extended_key(VK_HOME)
            time.sleep(0.08)
            
            processed += 1
            beep(1400, 80)
            time.sleep(0.2)
        except (pyautogui.FailSafeException, KeyboardInterrupt):
            raise
        except Exception as lead_err:
            print(f"[WARNING] Lead #{idx} par masla aaya: {lead_err}. Next line par move ho rahe hain...")
            try:
                pyautogui.click(n_x, n_y)
                time.sleep(0.05)
                press_extended_key(VK_DOWN)
                time.sleep(0.05)
                press_extended_key(VK_HOME)
            except Exception:
                pass
            time.sleep(0.5)
        
    print("\n" + "=" * 60)
    print(f"Mukammal! Total {processed} leads process ho chuki hain.")
    print(f"Log report: {LOG_CSV}")
    print("=" * 60)
    beep(1600, 200)

def run_local_file_hunter(query_wait=1.8):
    """
    Reads numbers from local leads.txt file on Host PC,
    types each directly into CRM Calling Number box,
    queries, reads table via OCR, and saves clean leads!
    """
    if not os.path.exists(LEADS_TXT):
        with open(LEADS_TXT, "w", encoding="utf-8") as f:
            f.write("# Har line par 1 phone number likhein, e.g.:\n# 3053844588\n# 3055000570\n")
        print(f"\n[INFO] Ek file banai gayi hai: {LEADS_TXT}")
        print("Is file me apne phone numbers paste karein aur dobara run karein!")
        return
        
    with open(LEADS_TXT, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip() and not line.startswith("#")]
        
    if not lines:
        print(f"\n{LEADS_TXT} me koi numbers nahi mile! Numbers paste kar ke save karein.")
        return
        
    coords = load_coords()
    if not coords:
        print("Coordinates nahi mile! Pehle Calibration chalayein.")
        coords = calibrate_coords()
        
    c_x, c_y = coords["calling_input"]
    q_x, q_y = coords["query_button"]
    t_x1, t_y1 = coords["table_top_left"]
    t_x2, t_y2 = coords["table_bottom_right"]
    bbox = (min(t_x1, t_x2), min(t_y1, t_y2), max(t_x1, t_x2), max(t_y1, t_y2))
    
    get_ocr_engine()
    
    total = len(lines)
    print("\n" + "=" * 60)
    print("      LOCAL LEADS.TXT MODE (DIRECT CRM TYPING)")
    print("=" * 60)
    print(f"Total Numbers to Process: {total}")
    print(f"Query Wait Time: {query_wait}s")
    print("Emergency Stop: Mouse ko Screen ke top-left (0,0) par le jayein!")
    print("=" * 60)
    
    countdown(5, ">>> VM CRM WINDOW SAMNE RAKHEIN <<<")
    
    today_str = datetime.now().strftime("%Y-%m-%d")
    clean_leads_count = 0
    
    for idx, num in enumerate(lines, 1):
        digits = re.sub(r'\D', '', num)
        if not digits:
            continue
            
        print(f"\n--- [{idx}/{total}] Checking: {digits} ---")
        try:
            # 1. Click CRM Calling Input
            pyautogui.click(c_x, c_y)
            time.sleep(0.08)
            hotkey_ctrl(VK_A)
            time.sleep(0.04)
            pyautogui.press('backspace')
            time.sleep(0.04)
            
            # 2. Type number into CRM
            pyautogui.write(digits, interval=0.01)
            time.sleep(0.08)
            
            # 3. Click Query
            pyautogui.click(q_x, q_y)
            time.sleep(query_wait)
            
            # 4. Screenshot table
            crop = ImageGrab.grab(bbox=bbox)
            
            # 5. Evaluate
            status, reason, count, detected_phone = parse_and_evaluate(crop, today_str)
            display_status = status if status else "(blank)"
            print(f"Result: [{display_status}] -> {reason}")
            
            log_result(digits, status, reason, count)
            if status == "A":
                clean_leads_count += 1
                
            beep(1400, 80)
            time.sleep(0.2)
        except (pyautogui.FailSafeException, KeyboardInterrupt):
            raise
        except Exception as lead_err:
            print(f"[WARNING] Lead {digits} par masla aaya: {lead_err}. Next lead check ki ja rahi hai...")
            log_result(digits, "ERR", f"Error: {lead_err}", 0)
            time.sleep(0.5)
        
    print("\n" + "=" * 60)
    print(f"Mukammal! Total {total} leads check ho gayi hain.")
    print(f"Clean Huntable Leads (A): {clean_leads_count}")
    print(f"Clean list yahan save hui: {CLEAN_LEADS_TXT}")
    print(f"Mukammal report: {LOG_CSV}")
    print("=" * 60)
    beep(1600, 200)
    beep(2000, 400)

def scan_leads_from_screen():
    print("\n" + "=" * 60)
    print("   SCREEN SE NUMBERS AUTO-EXTRACT (OCR SCANNER)")
    print("=" * 60)
    print("500 ya 1,000 numbers ke liye bhi tension nahi!")
    print("Bot screen capture karega, khud Page-Down scroll karega,")
    print("aur saare numbers baahir 'leads.txt' me le aayega!\n")
    
    pages_input = input("Kitne pages scroll karne hain? (e.g. 500 numbers ke liye 10 ya 15 likhein, default 1): ").strip()
    num_pages = int(pages_input) if pages_input.isdigit() else 1
    
    countdown(5, ">>> Step 1: Mouse ko NUMBERS LIST ke TOP-LEFT corner par rakhein <<<")
    p1 = pyautogui.position()
    print(f"Top-Left captured: ({p1.x}, {p1.y})")
    beep(1600, 150)
    
    countdown(5, ">>> Step 2: Mouse ko NUMBERS LIST ke BOTTOM-RIGHT corner par rakhein <<<")
    p2 = pyautogui.position()
    print(f"Bottom-Right captured: ({p2.x}, {p2.y})")
    beep(1600, 150)
    
    bbox = (min(p1.x, p2.x), min(p1.y, p2.y), max(p1.x, p2.x), max(p1.y, p2.y))
    center_x = (bbox[0] + bbox[2]) // 2
    center_y = (bbox[1] + bbox[3]) // 2
    
    engine = get_ocr_engine()
    all_numbers = []
    
    for page_idx in range(1, num_pages + 1):
        print(f"\n[Page {page_idx}/{num_pages}] Scanning screen...")
        crop = ImageGrab.grab(bbox=bbox)
        results, _ = engine(np.array(crop))
        
        if results:
            full_text = " ".join([r[1] for r in results])
            found = re.findall(r'\b(0?3\d{9})\b', full_text)
            print(f"  -> {len(found)} numbers is page par mile")
            all_numbers.extend(found)
        else:
            print("  -> Is page par text nahi mila")
            
        if page_idx < num_pages:
            # Click inside list area and scroll down
            pyautogui.click(center_x, center_y)
            time.sleep(0.08)
            pyautogui.press('pagedown')
            time.sleep(0.8)
            
    unique_numbers = list(dict.fromkeys(all_numbers))
    
    if not unique_numbers:
        print("\nKoi phone number detect nahi hua! Check karein ke screen par numbers saaf nazar aa rahe hain.")
        return
        
    print("\n" + "=" * 60)
    print(f"[MUBARAK!] Total {len(unique_numbers)} Unique Phone Numbers Kamyabi Se Scan Huye!")
    print("=" * 60)
    for n in unique_numbers[:10]:
        print(f"  -> {n}")
    if len(unique_numbers) > 10:
        print(f"  ... aur baqi {len(unique_numbers) - 10} numbers!")
        
    with open(LEADS_TXT, "w", encoding="utf-8") as f:
        for n in unique_numbers:
            f.write(f"{n}\n")
            
    print(f"\nSaare {len(unique_numbers)} numbers '{LEADS_TXT}' me save ho gaye hain!")
    print("Ab menu se Option 2 (Start with Host leads.txt) daba kar automatic check karein!")
    print("=" * 60)
    beep(1800, 250)
    beep(2200, 350)

def main():
    while True:
        print("\n" + "=" * 60)
        print("      CITRIX / VM LEAD HUNTER AUTOMATION BOT")
        print("=" * 60)
        print("1. Start with VM Notepad (Notepad se number copy/paste)")
        print("2. Start with Host leads.txt (leads.txt se direct check - Best!)")
        print("3. Scan Leads from Screen (VM screen se numbers khud nikal kar leads.txt me dalein)")
        print("4. Calibrate Screen Coordinates (Naye points set karein)")
        print("5. Exit")
        print("=" * 60)
        
        choice = input("Option select karein (1/2/3/4/5) [Default 1]: ").strip()
        if choice == "" or choice == "1":
            try:
                cnt = input("Kitne numbers check karne hain? (Default 50): ").strip()
                n = int(cnt) if cnt.isdigit() else 50
                run_vm_notepad_hunter(max_leads=n)
            except pyautogui.FailSafeException:
                print("\n[STOPPED] Failsafe trigger ho gaya! Bot ruk gaya.")
            except KeyboardInterrupt:
                print("\n[STOPPED] Bot ruk gaya.")
        elif choice == "2":
            try:
                run_local_file_hunter()
            except pyautogui.FailSafeException:
                print("\n[STOPPED] Failsafe trigger ho gaya! Bot ruk gaya.")
            except KeyboardInterrupt:
                print("\n[STOPPED] Bot ruk gaya.")
        elif choice == "3":
            try:
                scan_leads_from_screen()
            except pyautogui.FailSafeException:
                print("\n[STOPPED] Failsafe trigger ho gaya! Bot ruk gaya.")
            except KeyboardInterrupt:
                print("\n[STOPPED] Bot ruk gaya.")
            except Exception as e:
                print(f"\n[ERROR]: {e}")
        elif choice == "4":
            try:
                calibrate_coords()
            except (pyautogui.FailSafeException, KeyboardInterrupt):
                print("\n[STOPPED] Calibration cancel ho gayi.")
            except Exception as e:
                print(f"\n[ERROR]: {e}")
        elif choice == "5":
            print("Khuda Hafiz!")
            break
        else:
            print("Ghalat option, dobara try karein.")

if __name__ == "__main__":
    main()
