@echo off
title CITRIX LEAD HUNTER BOT
color 0b
echo ===================================================
echo       STARTING CITRIX LEAD HUNTER AUTOMATION
echo ===================================================
cd /d "%~dp0"
python lead_hunter_bot.py
pause
