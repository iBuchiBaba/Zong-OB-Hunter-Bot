import re
from datetime import datetime, time
from rapidocr_onnxruntime import RapidOCR
from PIL import Image

def test_screenshot_ocr():
    img_path = r'C:\Users\saveb\.gemini\antigravity\brain\89b7e7e3-b515-4cf3-afe5-52275e12b043\.user_uploaded\media_1791464700188_fe54e239.png'
    engine = RapidOCR()
    
    # We can crop the table result region from the screenshot
    # In the 1024x427 image:
    # Table headers start around y=200, bottom of table is y=260, pagination at y=265
    im = Image.open(img_path)
    w, h = im.size
    
    # Crop CRM table area
    table_crop = im.crop((0, int(h * 0.45), int(w * 0.8), h))
    table_crop.save(r'C:\Users\saveb\.gemini\antigravity\scratch\table_crop_test.png')
    
    import numpy as np
    results, _ = engine(np.array(table_crop))
    print("Table crop OCR results:")
    ocr_lines = []
    if results:
        for r in results:
            print("  ", r[1])
            ocr_lines.append(r[1])
            
    # Check if we detect records or dates or numbers
    full_text = " ".join(ocr_lines)
    phone_found = re.findall(r'0?3\d{9}', full_text)
    print("\nDetected phones in table:", phone_found)
    dates_found = re.findall(r'\d{4}[-/.]\d{2}[-/.]\d{2}', full_text)
    print("Detected dates in table:", dates_found)

if __name__ == '__main__':
    test_screenshot_ocr()
