import ctypes
import time
import winsound
import pyautogui

PUL = ctypes.POINTER(ctypes.c_ulong)

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ('wVk', ctypes.c_ushort),
        ('wScan', ctypes.c_ushort),
        ('dwFlags', ctypes.c_ulong),
        ('time', ctypes.c_ulong),
        ('dwExtraInfo', PUL)
    ]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ('uMsg', ctypes.c_ulong),
        ('wParamL', ctypes.c_short),
        ('wParamH', ctypes.c_ushort)
    ]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ('dx', ctypes.c_long),
        ('dy', ctypes.c_long),
        ('mouseData', ctypes.c_ulong),
        ('dwFlags', ctypes.c_ulong),
        ('time', ctypes.c_ulong),
        ('dwExtraInfo', PUL)
    ]

class Input_I(ctypes.Union):
    _fields_ = [
        ('ki', KEYBDINPUT),
        ('mi', MOUSEINPUT),
        ('hi', HARDWAREINPUT)
    ]

class INPUT(ctypes.Structure):
    _fields_ = [
        ('type', ctypes.c_ulong),
        ('ii', Input_I)
    ]

user32 = ctypes.windll.user32

KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008
INPUT_KEYBOARD = 1

VK_UP = 0x26
VK_DOWN = 0x28
VK_HOME = 0x24
VK_END = 0x23

def press_extended_key(vk):
    # Sends real navigation arrow key with EXTENDEDKEY flag
    ki_down = KEYBDINPUT(vk, 0, KEYEVENTF_EXTENDEDKEY, 0, None)
    ki_up = KEYBDINPUT(vk, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0, None)
    events = (INPUT * 2)(INPUT(INPUT_KEYBOARD, Input_I(ki=ki_down)),
                         INPUT(INPUT_KEYBOARD, Input_I(ki=ki_up)))
    user32.SendInput(2, events, ctypes.sizeof(INPUT))
    time.sleep(0.05)

def main():
    print("=" * 60)
    print("   TEST 3: EXTENDED KEY (REAL ARROW KEYS)")
    print("=" * 60)
    print("Aapne bilkul sahi pakda! Pehle Numpad numbers (8, 2, 1) type ho rahe the.")
    print("Ab hum Real Hardware Extended Arrow Keys send kar rahe hain.\n")
    print(">>> 5 SECONDS MEIN VM NOTEPAD PAR CLICK KAREIN! <<<")
    
    for i in range(5, 0, -1):
        print(f"Starting in {i} second{'s' if i > 1 else ''}...")
        try: winsound.Beep(900, 150)
        except: pass
        time.sleep(0.9)
        
    try: winsound.Beep(1500, 300)
    except: pass
    print("\n[TEST SHURU HO RAHA HAI...]")
    
    # 1. Type 3 lines
    pyautogui.write("\nROW_A\nROW_B\nROW_C\n", interval=0.03)
    time.sleep(0.5)
    
    # 2. Press Real Extended UP twice
    print("Real UP arrow pressing...")
    press_extended_key(VK_UP)
    time.sleep(0.15)
    press_extended_key(VK_UP)
    time.sleep(0.15)
    press_extended_key(VK_END)
    time.sleep(0.15)
    pyautogui.write(" <- REAL_UP_WORKED_ON_ROW_B!")
    time.sleep(0.5)
    
    # 3. Press Real Extended DOWN
    print("Real DOWN arrow pressing...")
    press_extended_key(VK_DOWN)
    time.sleep(0.15)
    press_extended_key(VK_END)
    time.sleep(0.15)
    pyautogui.write(" <- REAL_DOWN_WORKED_ON_ROW_C!")
    time.sleep(0.5)
    
    print("\n" + "=" * 60)
    print("TEST KHATAM! Check karein:")
    print("Kya ab '881' ya '21' type nahi hua, balki cursor ROW_B aur ROW_C par gaya?")
    print("=" * 60)
    input("Press Enter to exit...")

if __name__ == "__main__":
    main()
