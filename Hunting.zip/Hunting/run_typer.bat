@echo off
title Auto Typer for VM (Notepad)
cd /d "%~dp0"
python auto_typer.py
