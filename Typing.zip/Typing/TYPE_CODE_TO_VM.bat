@echo off
title Auto Typer (Python)
cd /d  %~dp0
python auto_typer.py
