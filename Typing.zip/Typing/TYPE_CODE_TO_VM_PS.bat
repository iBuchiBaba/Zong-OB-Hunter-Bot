@echo off
title Auto Typer (PowerShell SendKeys)
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File auto_typer.ps1
