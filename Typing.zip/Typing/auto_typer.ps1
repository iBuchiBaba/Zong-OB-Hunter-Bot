Add-Type -AssemblyName System.Windows.Forms
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$codeFile = Join-Path $scriptDir "code.txt"

if (-not (Test-Path $codeFile)) {
    Write-Host "Error: code.txt not found!" -ForegroundColor Red
    pause
    exit
}

$text = [System.IO.File]::ReadAllText($codeFile, [System.Text.Encoding]::UTF8)

Write-Host "=================================================" -ForegroundColor Cyan
Write-Host "   AUTO TYPER (POWERSHELL / SENDKEYS METHOD)     " -ForegroundColor Cyan
Write-Host "=================================================" -ForegroundColor Cyan
Write-Host "Loaded $($text.Length) characters from code.txt."
Write-Host ""
Write-Host ">>> 7 SECONDS MEIN VM NOTEPAD PAR CLICK KAREIN! <<<" -ForegroundColor Yellow
Write-Host ""

for ($i = 7; $i -ge 1; $i--) {
    Write-Host "Starting in $i second(s)..."
    try { [System.Console]::Beep(900, 150) } catch {}
    Start-Sleep -Milliseconds 850
}

Write-Host ""
Write-Host ">>> TYPING STARTED! (Window band na karein) <<<" -ForegroundColor Green
try { [System.Console]::Beep(1400, 300) } catch {}

$wshell = New-Object -ComObject Wscript.Shell

$chars = $text.ToCharArray()
$totalChars = $chars.Count

for ($i = 0; $i -lt $totalChars; $i++) {
    $c = $chars[$i]
    if ($c -eq "`r") {
        continue
    } elseif ($c -eq "`n") {
        $wshell.SendKeys("{ENTER}")
        Start-Sleep -Milliseconds 25
    } elseif ($c -eq "`t") {
        $wshell.SendKeys("{TAB}")
        Start-Sleep -Milliseconds 10
    } elseif ("{}+^%~()[]".IndexOf($c) -ge 0) {
        $wshell.SendKeys("{" + $c + "}")
        Start-Sleep -Milliseconds 5
    } else {
        $wshell.SendKeys($c)
        Start-Sleep -Milliseconds 5
    }

    if (($i + 1) % 40 -eq 0 -or ($i + 1) -eq $totalChars) {
        $pct = [math]::Round((($i + 1) / $totalChars) * 100)
        Write-Host "`rProgress: $pct% ($($i + 1)/$totalChars chars)" -NoNewline -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "`nTyping Complete! Notepad check karein." -ForegroundColor Green
try {
    [System.Console]::Beep(1500, 200)
    [System.Console]::Beep(1800, 350)
} catch {}
Write-Host "Press any key to exit..."
$null = [System.Console]::ReadKey()
